/*
 * Name: Nicholas Donofrio
 * Course: CNT 4714 – Spring 2024 – Project Four
 * Assignment title: A Three-Tier Distributed Web-Based Application
 * Date: April 23, 2024
 */

import java.io.*;
import java.sql.*;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.util.Properties;


public class AccountantServlet extends HttpServlet {
    private Connection connection;
    private Statement statement;

    public void init() {
        getDBConnection();
    }

    public void destroy() {
        try {
            if (statement != null) {
                statement.close();
            }
            if (connection != null) {
                connection.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String option = request.getParameter("option");
        String result = null;

        if (option != null) {
            result = switch (option) {
                case "1" -> getMaxStatusValueOfSuppliers();
                case "2" -> getTotalWeightOfParts();
                case "3" -> getTotalNumberOfShipments();
                case "4" -> getNameAndNumberOfWorksOfJobWithMostWorkers();
                case "5" -> listNameAndStatusOfSuppliers();
                default -> "Invalid option";
            };
        }

        request.setAttribute("result", result);
        RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/accountantHome.jsp");
        dispatcher.forward(request, response);
    }

    private String getMaxStatusValueOfSuppliers() {
        String result = null;
        try {
            ResultSet resultSet = statement.executeQuery("SELECT MAX(status) FROM suppliers");
            if (resultSet.next()) {
                result = resultSet.getString(1);
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error executing SQL query", e);
        }
        return result;
    }

    private String getTotalWeightOfParts() {
        String result = null;
        try {
            ResultSet resultSet = statement.executeQuery("SELECT SUM(weight) FROM parts");
            if (resultSet.next()) {
                result = resultSet.getString(1);
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error executing SQL query", e);
        }
        return result;
    }

    private String getTotalNumberOfShipments() {
        String result = null;
        try {
            ResultSet resultSet = statement.executeQuery("SELECT COUNT(*) FROM shipments");
            if (resultSet.next()) {
                result = resultSet.getString(1);
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error executing SQL query", e);
        }
        return result;
    }

    private String getNameAndNumberOfWorksOfJobWithMostWorkers() {
        String result = null;
        try {
            ResultSet resultSet = statement.executeQuery("SELECT jname, COUNT(*) AS numworkers FROM jobs GROUP BY jname ORDER BY numworkers DESC LIMIT 1");
            if (resultSet.next()) {
                String jobName = resultSet.getString("jname");
                int numWorkers = resultSet.getInt("numworkers");
                result = jobName + ": " + numWorkers + " numworkers";
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error executing SQL query", e);
        }
        return result;
    }

    private String listNameAndStatusOfSuppliers() {
        StringBuilder result = new StringBuilder();
        try {
            ResultSet resultSet = statement.executeQuery("SELECT sname, status FROM suppliers");
            result.append("<table>");
            result.append("<tr><th>Name</th><th>Status</th></tr>");
            while (resultSet.next()) {
                String name = resultSet.getString("sname");
                String status = resultSet.getString("status");
                result.append("<tr><td>").append(name).append("</td><td>").append(status).append("</td></tr>");
            }
            result.append("</table>");
        } catch (SQLException e) {
            throw new RuntimeException("Error executing SQL query", e);
        }
        return result.toString();
    }

    public void getDBConnection() {
        Properties props = new Properties();
        try {
            FileInputStream in = new FileInputStream("C:/Program Files/Apache Software Foundation/Tomcat 10.1/webapps/Project4/WEB-INF/lib/theaccountant.properties");
            props.load(in);
            in.close();

            // Retrieve database connection parameters from properties
            String driver = props.getProperty("MYSQL_DB_DRIVER_CLASS");
            String url = props.getProperty("MYSQL_DB_URL");
            String dbUsername = props.getProperty("MYSQL_DB_USERNAME");
            String dbPassword = props.getProperty("MYSQL_DB_PASSWORD");

            // Load JDBC driver and establish connection to database
            Class.forName(driver);
            connection = DriverManager.getConnection(url, dbUsername, dbPassword);
            statement = connection.createStatement();
        } catch (IOException | ClassNotFoundException | SQLException e) {
            throw new RuntimeException("Error establishing database connection", e);
        }
    }

}
