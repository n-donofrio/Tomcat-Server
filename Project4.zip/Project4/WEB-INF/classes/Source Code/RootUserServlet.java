/*
 * Name: Nicholas Donofrio
 * Course: CNT 4714 – Spring 2024 – Project Four
 * Assignment title: A Three-Tier Distributed Web-Based Application
 * Date: April 23, 2024
 */

// Imports______________________________________
import jakarta.servlet.*;  // Importing Servlet API
import jakarta.servlet.http.*;  // Importing Servlet HTTP API
import java.util.Properties;  // Importing Properties class for handling property lists
import java.io.*;  // Importing Input/Output classes
import java.sql.*;  // Importing JDBC classes for database connectivity

// Public class for root_user____________________________________
public class RootUserServlet extends HttpServlet {  // Class declaration extending HttpServlet
    // Instance variables to store database connection and statement objects
    private Connection connection;
    private Statement statement;


    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String textBox = request.getParameter("textBox");  // Retrieving input from text box
        String message = null;  // Initializing message variable

        if (textBox != null) {  // Checking if text box input is not null
            getDBConnection();  // Establishing database connection
            if (textBox.contains("select")) {  // Checking if SQL query is a select statement
                try {
                    message = doSelectQuery(textBox);  // Executing select query
                } catch (SQLException error) {  // Catching SQL exceptions
                    StringBuilder html = new StringBuilder();  // Creating StringBuilder object
                    html.append("<table><tr><td align=\"center\" style=\"background-color: red;\">");  // Building error message HTML
                    html.append("<h3 style='text-align: left;'><span class='font-bold'> Error executing the SQL statement:</span></h3>");
                    html.append("<h3 style='text-align: left;'>" + error.getMessage() + "</h3>");
                    html.append("</td></tr></table>");
                    message = html.toString();  // Converting StringBuilder to String
                    error.printStackTrace();  // Printing stack trace for debugging
                }

            } else {  // If SQL query is not a select statement
                try {
                    message = doUpdateQuery(textBox);  // Executing update query
                } catch (SQLException error) {  // Catching SQL exceptions
                    StringBuilder html = new StringBuilder();  // Creating StringBuilder object
                    html.append("<table><tr><td align=\"center\" style=\"background-color: red;\">");  // Building error message HTML
                    html.append("<h3 style='text-align: left;'><span class='font-bold'> Error executing the SQL statement:</span></h3>");
                    html.append("<h3 style='text-align: left;'>" + error.getMessage() + "</h3>");
                    html.append("</td></tr></table>");
                    message = html.toString();  // Converting StringBuilder to String
                    error.printStackTrace();  // Printing stack trace for debugging
                }
            }
        }

        HttpSession session = request.getSession();  // Retrieving session object from request
        session.setAttribute("message", message);  // Setting message attribute in session
        session.setAttribute("textBox", textBox);  // Setting textBox attribute in session
        RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/rootHome.jsp");  // Creating dispatcher object
        dispatcher.forward(request, response);  // Forwarding request and response to rootHome.jsp
    }

    // Method to execute select SQL queries
    private String doSelectQuery(String textBox) throws SQLException {
        String result;  // Declaring result variable

        ResultSet table = statement.executeQuery(textBox);  // Executing SQL query and retrieving ResultSet
        ResultSetMetaData metaData = table.getMetaData();  // Retrieving ResultSet metadata

        int numOfColumns = metaData.getColumnCount();  // Getting number of columns in ResultSet
        String tableOpeningHTML = "<table class='w-full text-left'>";  // Building HTML for opening table tag
        String tableColumnsHTML = "<thead><tr>";  // Building HTML for table column headers
        for (int i = 1; i <= numOfColumns; i++) {  // Looping through column headers
            tableColumnsHTML += "<th class='text-lg'>" + metaData.getColumnName(i) + "</th>";  // Adding column header HTML
        }
        tableColumnsHTML += "</tr></thead>";  // Closing table row tag

        String tableBodyHTML = "<tbody>";  // Building HTML for table body
        int counter = 1;  // Initializing counter variable
        while (table.next()) {  // Looping through ResultSet rows
            if (counter % 2 == 0) {  // Checking if row is even
                tableBodyHTML += "<tr>";  // Adding table row HTML
            } else {  // If row is odd
                tableBodyHTML += "<tr>";  // Adding table row HTML
            }
            for (int i = 1; i <= numOfColumns; i++) {  // Looping through columns in current row
                tableBodyHTML += "<td class='p-1'>" + table.getString(i) + "</td>";  // Adding table cell HTML with data
            }
            tableBodyHTML += "</tr>";  // Closing table row tag
            counter += 1;  // Incrementing counter
        }

        tableBodyHTML += "</tbody></table>";  // Closing table body tag
        result = tableOpeningHTML + tableColumnsHTML + tableBodyHTML;  // Concatenating all HTML parts
        return result;  // Returning HTML table
    }

    // Method to execute update SQL queries
    private String doUpdateQuery(String textBox) throws SQLException {
        String result = null;  // Declaring result variable
        int rowsAffected = 0;  // Initializing variable to store number of affected rows
        int rowsUpdated = 0;  // Initializing variable to store number of updated rows
        int quantity = 0;  // Initializing variable to store quantity value

        rowsAffected = statement.executeUpdate(textBox);  // Executing update query and getting number of affected rows
        StringBuilder html = new StringBuilder();  // Creating StringBuilder object for building HTML response
        html.append("<table><tr><td align=\"center\" style=\"background-color: #00ff15;\">");  // Building success message HTML

        if (textBox.contains("shipments") || textBox.contains("suppliers") || textBox.contains("jobs") || textBox.contains("parts")) {  // Checking if update involves specific tables
            rowsUpdated = statement.getUpdateCount();  // Getting number of rows updated
            String[] check = textBox.split(",");  // Splitting SQL query by commas
            if (check.length == 4) {  // Checking if query contains quantity value
                try {
                    quantity = Integer.parseInt(check[3].replaceAll("[^\\d]", ""));  // Parsing quantity value from query
                } catch (NumberFormatException e) {
                    System.err.println("Error: Quantity must be an integer value.");  // Printing error message if quantity is not an integer
                }
            }

            if (textBox.contains("shipments") && textBox.contains("pnum = 'P3'")) {  // Checking for specific condition in shipment query
                html.append("<h4>The statement executed successfully.</h4>");  // Adding success message
// END