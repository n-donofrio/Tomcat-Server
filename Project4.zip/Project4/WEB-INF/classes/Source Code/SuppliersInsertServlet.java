/*
 * Name: Nicholas Donofrio
 * Course: CNT 4714 – Spring 2024 – Project Four
 * Assignment title: A Three-Tier Distributed Web-Based Application
 * Date: April 23, 2024
 */

// Imports
import jakarta.servlet.*; // Import Servlet API
import jakarta.servlet.http.*; // Import HTTP Servlet API
import java.util.Properties; // Import Properties class for handling properties files
import java.io.*; // Import Input/Output classes
import java.sql.*; // Import JDBC classes for database operations

// SuppliersInsert Class_____________________________________
public class SuppliersInsertServlet extends HttpServlet { // Define SuppliersInsertServlet class inheriting from HttpServlet
    private Connection connection; // Declare Connection variable for database connection
    private Statement statement; // Declare Statement variable for executing SQL statements

    // Handles HTTP POST requests
    protected void doPost(HttpServletRequest request, HttpServletResponse response) // Define doPost method with HTTP request and response objects
            throws ServletException, IOException { // Handle ServletException and IOException
        // Retrieving parameters from the HTTP request
        String snum = request.getParameter("snum"); // Retrieve "snum" parameter from request
        String sname = request.getParameter("sname"); // Retrieve "sname" parameter from request
        String status = request.getParameter("status"); // Retrieve "status" parameter from request
        String city = request.getParameter("city"); // Retrieve "city" parameter from request
        String message = ""; // Initialize message variable for response message

        try {
            // Check if database connection is established
            if (statement == null) {
                getDBConnection(); // If connection is not established, create one
            }
            // Execute SQL INSERT statement to add supplier record
            statement.executeUpdate("INSERT INTO project4.suppliers" + " (snum, sname, status, city) VALUES " + " ('" + snum + "', '" + sname + "', '" + status + "', '" + city + "');");
            // Construct success message
            StringBuilder html = new StringBuilder();
            html.append("<table style='border: 2px solid red;'><tr><td class='font-bold' style='font-size: 14px; padding: 8px; font-weight: bold; color: #FFFFFF; background-color: green;'>");
            html.append("New suppliers record:" + " (" + snum + ", " + sname + ", " + status + ", " + city + ") - ");
            html.append("successfully entered into database. </td></tr></font></table>");
            message = html.toString(); // Convert StringBuilder to String

        } catch (SQLException error) {
            // Construct error message if SQL operation fails
            StringBuilder html = new StringBuilder();
            html.append("<table style='border: 2px solid red;'><tr><td class='font-bold' style='font-size: 14px; padding: 10px; font-weight: bold; color: #FFFFFF; background-color: red;'>");
            html.append("Error executing the SQL statement:<br>");
            html.append(error.getMessage());
            html.append("</td></tr></table>");
            message = html.toString(); // Convert StringBuilder to String
            error.printStackTrace(); // Print stack trace for debugging
        }

        // Set message attribute and forward request to dataentryHome.jsp
        request.setAttribute("message", message); // Set message attribute for JSP
        request.getRequestDispatcher("/dataentryHome.jsp").forward(request, response); // Forward request to dataentryHome.jsp
    }

    // Establishes database connection
    public void getDBConnection() throws ServletException { // Define getDBConnection method, may throw ServletException
        Properties props = new Properties(); // Create Properties object to load database properties
        try {
            // Load database properties from data.properties file
            FileInputStream in = new FileInputStream("C:/Program Files/Apache Software Foundation/Tomcat 10.1/webapps/Project4/WEB-INF/lib/data.properties");
            props.load(in); // Load properties
            in.close(); // Close input stream
        } catch (IOException e) {
            // Throw ServletException if properties file cannot be loaded
            throw new ServletException("Cannot load database properties", e);
        }

        // Retrieve database connection parameters from properties
        String driver = props.getProperty("MYSQL_DB_DRIVER_CLASS"); // Get JDBC driver class
        String url = props.getProperty("MYSQL_DB_URL"); // Get database URL
        String dbUsername = props.getProperty("MYSQL_DB_USERNAME"); // Get database username
        String dbPassword = props.getProperty("MYSQL_DB_PASSWORD"); // Get database password

        try {
            // Load JDBC driver and establish connection to database
            Class.forName(driver); // Load JDBC driver class
            connection = DriverManager.getConnection(url, dbUsername, dbPassword); // Establish database connection
            statement = connection.createStatement(); // Create statement for executing SQL queries
        } catch (ClassNotFoundException e) {
            // Throw ServletException if JDBC driver cannot be loaded
            throw new ServletException("Cannot load JDBC driver", e);
        } catch (SQLException e) {
            // Throw ServletException if connection to database cannot be established
            throw new ServletException("Cannot connect to database", e);
        }
    }
}
