/*
 * Name: Nicholas Donofrio
 * Course: CNT 4714 – Spring 2024 – Project Four
 * Assignment title: A Three-Tier Distributed Web-Based Application
 * Date: April 23, 2024
 */

// Importing necessary packages and classes
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.util.Properties;
import java.io.*;
import java.sql.*;

// PartsInsertServlet Class
public class PartsInsertServlet extends HttpServlet {
    private Connection connection; // Connection object to interact with the database
    private Statement statement; // Statement object to execute SQL queries

    // doPost method handles HTTP POST requests
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Retrieving data from the HTTP request parameters
        String pnum = request.getParameter("pnum");
        String pname = request.getParameter("pname");
        String color = request.getParameter("color");
        String weight = request.getParameter("weight");
        String city = request.getParameter("city");
        String message = ""; // Initializing message variable to store response message

        try {
            // Checking if the statement is null and establishing a database connection if necessary
            if (statement == null) {
                getDBConnection();
            }
            // Executing SQL query to insert data into the 'parts' table
            statement.executeUpdate("INSERT INTO project4.parts" + " (pnum, pname, color, weight, city) VALUES " + " ('" + pnum + "', '" + pname + "', '" + color + "', '" + weight + "', '" + city + "');");
            StringBuilder html = new StringBuilder(); // StringBuilder to construct HTML response
            // Constructing success message
            html.append("<table style='border: 2px solid red;'><tr><td class='font-bold' style='font-size: 14px; padding: 8px; font-weight: bold; color: #FFFFFF; background-color: green;'>");
            html.append("New parts record:" + " (" + pnum + ", " + pname + ", " + color + ", " + weight + ", " + city + ") - ");
            html.append("successfully entered into database. </td></tr></font></table>");
            message = html.toString(); // Converting StringBuilder to String

        } catch (SQLException error) { // Catching SQL exceptions
            StringBuilder html = new StringBuilder(); // StringBuilder to construct HTML response for error
            html.append("<table style='border: 2px solid red;'><tr><td class='font-bold' style='font-size: 14px; padding: 10px; font-weight: bold; color: #FFFFFF; background-color: red;'>");
            html.append("Error executing the SQL statement:<br>"); // Constructing error message
            html.append(error.getMessage()); // Retrieving error message
            html.append("</td></tr></table>");
            message = html.toString(); // Converting StringBuilder to String
            error.printStackTrace(); // Printing stack trace for debugging
        }

        // Setting the message attribute in the request for retrieval in JSP
        request.setAttribute("message", message);
        // Forwarding the request and response objects to the dataentryHome.jsp page
        request.getRequestDispatcher("/dataentryHome.jsp").forward(request, response);
    }

    // Method to establish a database connection
    public void getDBConnection() throws ServletException {
        Properties props = new Properties(); // Creating Properties object to hold database properties
        try {
            FileInputStream in = new FileInputStream("C:/Program Files/Apache Software Foundation/Tomcat 10.1/webapps/Project4/WEB-INF/lib/data.properties"); // Loading database properties file
            props.load(in); // Loading properties from file
            in.close(); // Closing FileInputStream
        } catch (IOException e) {
            throw new ServletException("Cannot load database properties", e); // Throwing ServletException if properties file cannot be loaded
        }

        String driver = props.getProperty("MYSQL_DB_DRIVER_CLASS"); // Retrieving database driver from properties
        String url = props.getProperty("MYSQL_DB_URL"); // Retrieving database URL from properties
        String dbUsername = props.getProperty("MYSQL_DB_USERNAME"); // Retrieving database username from properties
        String dbPassword = props.getProperty("MYSQL_DB_PASSWORD"); // Retrieving database password from properties

        try {
            Class.forName(driver); // Loading JDBC driver class
            // Establishing connection to the database using retrieved properties
            connection = DriverManager.getConnection(url, dbUsername, dbPassword);
            statement = connection.createStatement(); // Creating Statement object
        } catch (ClassNotFoundException e) {
            throw new ServletException("Cannot load JDBC driver", e); // Throwing ServletException if JDBC driver cannot be loaded
        } catch (SQLException e) {
            throw new ServletException("Cannot connect to database", e); // Throwing ServletException if connection to database cannot be established
        }
    }
}
